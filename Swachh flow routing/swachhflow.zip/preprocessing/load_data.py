import pandas as pd

def dms_to_decimal(dms):
    """
    Converts 17°23'23.38"N → 17.38983
    """
    dms = dms.replace("°", " ").replace("'", " ").replace('"', " ")
    parts = dms.split()

    degrees = float(parts[0])
    minutes = float(parts[1])
    seconds = float(parts[2])
    direction = parts[3]

    decimal = degrees + minutes/60 + seconds/3600

    if direction in ["S", "W"]:
        decimal *= -1

    return decimal

def load_data():
    gvps = pd.read_excel("data/gvps.xlsx")
    sctps = pd.read_excel("data/sctps.xlsx")
    trucks = pd.read_excel("data/trucks.xlsx")

    # Convert SCTP coordinates
    sctps["lat"] = sctps["latitude"].apply(dms_to_decimal)
    sctps["long"] = sctps["longitude"].apply(dms_to_decimal)

    return gvps, sctps, trucks
