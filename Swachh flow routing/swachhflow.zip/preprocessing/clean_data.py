import re

def dms_to_decimal(dms):
    """
    Converts 17°23'23.38"N → 17.38983
    """
    parts = re.split('[°\'"]+', dms)
    degrees = float(parts[0])
    minutes = float(parts[1])
    seconds = float(parts[2])
    direction = dms[-1]

    decimal = degrees + minutes/60 + seconds/3600

    if direction in ['S', 'W']:
        decimal *= -1

    return decimal
def clean_gvps(gvps):
    gvps = gvps.dropna(subset=["lat", "long", "waste_generated"])
    gvps = gvps[gvps["waste_generated"] > 0]
    return gvps

def clean_sctps(sctps):
    sctps = sctps.dropna(subset=["latitude", "longitude"])

    sctps["lat"] = sctps["latitude"].apply(dms_to_decimal)
    sctps["long"] = sctps["longitude"].apply(dms_to_decimal)

    return sctps


def clean_trucks(trucks):
    return trucks.dropna(subset=["capacity", "count"])
