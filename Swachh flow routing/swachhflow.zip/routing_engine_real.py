import pandas as pd
from ortools.constraint_solver import pywrapcp, routing_enums_pb2

from time_matrix_real import build_time_matrix
from distance_utils import haversine_distance

def load_data():
    gvps = pd.read_excel("data/gvps.xlsx")
    sctps = pd.read_excel("data/sctps.xlsx")
    trucks = pd.read_excel("data/trucks.xlsx")
    return gvps, sctps, trucks

def build_nodes(gvps, sctps):
    nodes = []

    # Depot (only ONE for now)
    nodes.append({
        "id": sctps.iloc[0]["Transferstation"],
        "lat": sctps.iloc[0]["latitude"],
        "lng": sctps.iloc[0]["longitude"],
        "demand": 0
    })

    # GVPs
    for _, row in gvps.iterrows():
        nodes.append({
            "id": row["Location of the GVPs"],
            "lat": row["Latitude"],
            "lng": row["Longitude"],
            "demand": float(row["Estimated Waste Generation"])
        })

    return nodes

def build_vehicles(trucks_df):
    vehicle_capacities = []

    for _, row in trucks_df.iterrows():
        vehicle_capacities.extend(
            [int(row["Payload Capacity (in Tonnes)"])] * int(row["No. of Vehicles Available"])
        )

    return vehicle_capacities

def solve_routing(nodes, time_matrix, vehicle_capacities):
    manager = pywrapcp.RoutingIndexManager(
        len(time_matrix),
        len(vehicle_capacities),
        0  # depot index
    )

    routing = pywrapcp.RoutingModel(manager)

    def time_callback(from_index, to_index):
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return int(time_matrix[from_node][to_node])

    transit_cb = routing.RegisterTransitCallback(time_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_cb)

    # Capacity constraint
    def demand_callback(index):
        node = manager.IndexToNode(index)
        return int(nodes[node]["demand"])

    demand_cb = routing.RegisterUnaryTransitCallback(demand_callback)

    routing.AddDimensionWithVehicleCapacity(
        demand_cb,
        0,
        vehicle_capacities,
        True,
        "Capacity"
    )

    search_params = pywrapcp.DefaultSearchParameters()
    search_params.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    )

    solution = routing.SolveWithParameters(search_params)
    return routing, manager, solution

def extract_routes(routing, manager, solution, nodes):
    routes = []

    for vehicle_id in range(routing.vehicles()):
        index = routing.Start(vehicle_id)
        route = []
        total_time = 0

        while not routing.IsEnd(index):
            node_index = manager.IndexToNode(index)
            route.append(nodes[node_index]["id"])
            prev_index = index
            index = solution.Value(routing.NextVar(index))
            total_time += routing.GetArcCostForVehicle(
                prev_index, index, vehicle_id
            )

        routes.append({
            "truck_id": f"T{vehicle_id}",
            "route": route,
            "total_time": total_time
        })

    return routes

if __name__ == "__main__":
    gvps, sctps, trucks = load_data()
    nodes = build_nodes(gvps, sctps)
    vehicle_capacities = build_vehicles(trucks)

    time_matrix = build_time_matrix(nodes)

    routing, manager, solution = solve_routing(
        nodes,
        time_matrix,
        vehicle_capacities
    )

    if solution:
        routes = extract_routes(routing, manager, solution, nodes)
        for r in routes:
            print(r)
    else:
        print("No solution found")

with open("outputs/routes_real.json", "w") as f:
    json.dump(routes, f, indent=2)
