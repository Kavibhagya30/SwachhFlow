def dms_to_decimal(dms):
    dms = dms.replace("°", " ").replace("'", " ").replace('"', "")
    parts = dms.split()
    deg, min_, sec = map(float, parts[:3])
    direction = parts[3]

    decimal = deg + min_/60 + sec/3600
    if direction in ["S", "W"]:
        decimal *= -1
    return decimal
